// wap for find domain and user name

// let myInput,string,uname,domain;

// let result = () =>{
//      myInput = document.getElementById('input').value;
//      string =  myInput.search("@")
//      uname =  myInput.slice(0,string);
//      domain = myInput.slice(string+1,myInput.length);
//      document.getElementById("output").innerHTML += " your user name is  "+uname + " and domain is " + domain;
//     }


//   wap for ******** name pattern

// let myInput,string,uname,domain;

// let result = () =>{
//      myInput = document.getElementById('input').value;
//      string =  myInput.search("@")
//      uname =  myInput.slice(0,3);
//      star =   myInput.slice(3,string).length;
//      domain = myInput.slice(string,myInput.length);
//      document.getElementById("output").innerHTML += " " + uname + "*".repeat(star) + domain ;
//     }

//   wap for obrivation

// let result = () =>{
//      myInput = document.getElementById('input').value;
//      string =  myInput.split(" ")
//      fname =  string[0].substr(0,1).toUpperCase();
//      mname =  string[1].substr(0,1).toUpperCase();
//      lname =  string[2].substr(0,1).toUpperCase()
//         x  =   string[2].substr(1,string[2].length)
//      document.getElementById("output").innerHTML += " " + fname + ". " + mname + ". " + lname + x ;
//     }


// wap for add ()()() and normal also

// function z(arguments) {
//     var sum=0;
//     for(i=0;i<arguments.length;i++)
//     {
//     sum+=arguments[i];
//     }
//     return sum;
//     }
    
//     function add(a,d) {
//        if ( d == undefined){
//        var sum = a
//     function myFun(b) {
//     if(b){
//     sum += b
//     return myFun
//     }
//     }
//     myFun.toString = function() { return sum }
//     return myFun
//     } else return z(arguments);
    
//     }

