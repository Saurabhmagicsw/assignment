setInterval(() => {
    let a = d = new Date
    let clock = a.toLocaleTimeString();
    document.getElementById("cl").innerText = clock;
}, 100);

let s =() => {
    let a = Math.random()*1000000;
    let b = Math.floor(a);
    return '#'+b;
    
   
  }


setInterval(() => {
    document.getElementById('div1').style.backgroundColor = s();
},3000)

function change() {  
     
    var color =[ "red", "yellow", "green"];  
    for(let i=0; i<color.length; i++){  
         return color[i];  
        
      
     }for(let i=1; i<color.length; i++){  
        return color[i];  
       
     
    }for(let i=2; i<color.length; i++){  
        return color[i];  
       
     
    }
  }  



setInterval(() => {
    document.getElementById('div2').style.backgroundColor = change();
},3000)